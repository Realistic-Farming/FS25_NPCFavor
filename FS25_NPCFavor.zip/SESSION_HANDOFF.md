# NPCFavor - AI Field Work Session Handoff

> LOCAL working note. Do NOT commit this to the public repo (Realistic-Farming/FS25_NPCFavor).
> Written 2026-07-04 to continue the NPC AI field-work work in a fresh session.

---

## Status snapshot

- Branch `development` is AHEAD of `main` (do the PR from development, never commit to main).
- Version bumped to **1.2.7.0** on development (modDesc.xml + CHANGELOG.md). RELEASE IS HELD (not published).
- Existing GitHub release `v1.2.6.1` is a PRE-RELEASE (yesterday's ecosystem test drop, old code). The plan is to cut `v1.2.7.0` as a full release and remove the `v1.2.6.1` pre-release, AFTER field work is polished + tested.
- Build/deploy: `py build.py --deploy` (from the mod folder). Syntax check any .lua with fengari before building (see `../FS25_SoilFertilizer/tools/test/node_modules/fengari`).
- Game log: `%USERPROFILE%/Documents/My Games/FarmingSimulator2025/log.txt`. Filter for `[NPC Favor]` / `[NPCEntity]`.

## Solid, banked fixes (release-worthy regardless of field work)

- Map-marker overlay spam ("Unknown entity id ... renderOverlay", was flooding 10k-49k lines/session): fixed by sharing ONE never-freed overlay across all NPC hotspots. VERIFIED in-game (0 occurrences).
- VehicleCharacter crash (wrong `loadCharacter` arg order, was calling a table): fixed. VERIFIED (0 occurrences).
- 5 no-op vehicle deletions: `g_currentMission:removeVehicle` does NOT exist; switched to `Vehicle:delete()`.
- New console command `npcDeleteVehicle [radius]`. VERIFIED working in-game.
- "Can't change money of spectator farm": zeroed AI job cost (`job.getPricePerMs = function() return 0 end`). VERIFIED (0 occurrences).

## What the AI field-work feature does now (functional, but rough)

Each farmer NPC gets a job ROLE and, at INIT, spawns matching equipment; it runs a real base-game AI job only when the field's live state matches the role.

- `getFieldJobType(field)` reads crop/growth via `FieldState.new():update(x,z)` (`.fruitTypeIndex`, `.growthState`) + `FruitTypeDesc:getIsHarvestable/getIsCut/getIsGrowing`. Returns "open" / "harvest" / "protect".
- `getNPCJobRole(npc)` (field-aware, cached): ripe field -> "harvest", open field -> "till" or "sow" (seed), growing field -> "inspect" (bare tractor, no plow).
- Real tillage: `startNPCFieldWorkOwned` uses AIJobFieldWork. The AI helper requires the JOB's farm to own the field, and NPC farms do not own land, so we TEMPORARILY flip the field's farmland to the local player's farm for the job, then restore. A save-hook safeguard (`restoreAllOwnershipFlips` at the top of `saveToXMLFile`) restores every flip before any save, so a borrow can never persist.
- Fallbacks: `startNPCComboGoTo` (real base-game AIJobGoTo pathfinding, NO ownership check) drives the combo when tillage cannot run; then a kinematic visual pass.
- Guardrail: `MAX_NPC_AI_JOBS = 2` + `getAILimitedReached()` so NPC jobs never starve the player's hire limit.

## ON-DEMAND EQUIPMENT — IMPLEMENTED 2026-07-04 (needs in-game test)

The pre-spawn architecture was replaced with on-demand spawn/despawn. Vehicles are
no longer parked at fields at init; each NPC's equipment is spawned at the field
edge when they actually enter WORKING, matched to the field's CURRENT need, and
despawned when they leave. This structurally removes the stale-equipment mismatch
(old rough edges 1 and 3) — role + equipment are decided at work time from the live
field, so they can never go stale.

What changed (NPCSystem.lua + NPCAI.lua):
- `initializeNPCVehicles()` no longer pre-spawns. It validates pools once and logs
  "Field vehicles are on-demand". The old maxConcurrent spawn loop is gone.
- New `NPCSystem:spawnFieldWorkVehicle(npc)` (the orchestrator) + `countActiveFieldVehicles()`
  + `NPCSystem.MAX_FIELD_VEHICLES = 4`. It: guards mode/server/caps, clears the
  cached role (`npc.jobRole`, `npc._harvestComboIndex`) so the role rebuilds from the
  live field, skips spawning on a growing crop (`need == "protect"` -> NPC visits on
  foot), then async-spawns via `spawnNPCTractor` and, in the callback, seats + starts
  the AI via `activateNPCTractor`. Strand guard: if the NPC left WORKING or the spawn
  failed by callback time, it removes the vehicle. `_pendingFieldSpawn` prevents
  double-spawn and is cleared first thing in the callback so the cap never leaks.
- `spawnNPCTractor` now fires its caller callback AFTER the implement attach resolves
  (nil on tractor-spawn fail), so on-demand activation sees a field-work-ready combo
  instead of a bare tractor that always fell through to driving.
- `NPCAI:startWorking` calls `spawnFieldWorkVehicle` instead of `activateNPCTractor`.
  If a spawn starts, it skips the tractor prop; if not (growing crop / caps / mode
  off / async fail), the NPC works the rows on foot as before.
- `NPCAI:setState` leave-WORKING now calls `removeNPCTractor` (despawn) instead of
  `deactivateNPCTractor` (which only parked it). `deactivateNPCTractor` is now dead
  code, left in place to minimise churn.

Both files pass the Lua 5.1 syntax check (luaparse, via SoilFertilizer tools/test).

### Header attach — FIXED (was a data bug, not attach logic)
`HARVEST_COMBOS` paired `newHolland/cr980_830` (the "combine") with `varifeed28`.
But cr980_830.xml is `type="cutter"` — it is itself a HEADER (parentFile
caseIH/header4408), not a combine. So we were spawning a header and trying to attach
a second header (varifeed28, also type=cutter) to it -> no matching attacher/input
joint -> attach always failed. Fixed by pointing the combo at the REAL combine
`newHolland/chSeries/chSeries.xml` (type=combineDrivable, has a free
`jointType="cutter"` attacher joint). varifeed28's own store metadata already lists
chSeries as its combine, and both couple through the same jointType "cutter" path the
working claas pair uses. `attachImplementToTractor` was correct all along.
Lesson: validate each HARVEST_COMBOS combine is actually `type="combineDrivable"`,
not a cutter, before adding it. Game data lives at
`D:/SteamLibrary/steamapps/common/Farming Simulator 25/data/vehicles`.

### Churn optimization — DONE
On-demand spawn kicks off async at WORKING-entry; if the NPC left WORKING before the
tractor finished loading, the strand-guard already removed the vehicle — but only
AFTER also loading + attaching the header (wasteful i3d load). Added an earlier guard
inside `spawnNPCTractor`'s tractor-load callback: if `npc._pendingFieldSpawn` and the
NPC is no longer WORKING, despawn immediately and skip the implement load entirely.
Gated on `_pendingFieldSpawn` so non-on-demand callers are unaffected.

### Still open
- Old rough edge 4 (bare tractor driving rows on a growing field) is moot: growing
  fields now spawn NO equipment and the NPC just visits on foot.
- `Error: Can't change money of spectator farm` (seen 13:11:03) is a CROSS-MOD bug:
  FS25_WorkerCosts (`WorkerSystem.lua:200`) charges Motorized running costs on our
  spectator-farm NPC vehicles. Different path from NPCFavor's own AI-job-cost zeroing.
  Fix belongs in WorkerCosts (skip spectator/AI farms), not here.

### In-game test checklist for this change
- Log shows "Field vehicles are on-demand ..." at load (NOT the old per-NPC
  "Hybrid tractor parked at field" lines).
- Walk an NPC to an OPEN field -> a tractor+implement spawns at the edge when they
  start working; it tills/sows via AI (or drives via GoTo / kinematic fallback).
- Same NPC on a GROWING field -> NO vehicle spawns; they visit on foot.
- When the NPC leaves WORKING (break/storm/go-home) -> the vehicle is DELETED, not
  left parked. Confirm no accumulation of tractors over a day.
- Confirm no stranded vehicles if an NPC is interrupted mid-spawn (walk them away
  the instant they start).

## Key files / functions

- `src/NPCSystem.lua`:
  - Pools: `TRACTOR_POOL`, `IMPLEMENT_POOL`, `SEEDER_POOL`, `HARVEST_COMBOS`, `MAX_NPC_AI_JOBS`. Validated in `validateVehiclePools()`.
  - Roles: `getNPCJobRole`, `getWorkVehicleFilename`, `getImplementFilename`, `getFieldJobType`.
  - Spawn: `spawnNPCTractor`, `spawnNPCImplement` (attach via `attachImplementToTractor`, seed fill via `fillSeederWithSeed`), `initializeNPCVehicles` (maxConcurrent = 4).
  - Real AI: `startNPCFieldWorkOwned` (tillage + temp ownership), `startNPCComboGoTo` / `startGoToWaypoint` / `advanceNPCGoTo` / `stopNPCGoTo` (GoTo driving), `activateNPCTractor` (tries fieldwork -> GoTo -> kinematic), `onAIJobStopped`, `deactivateNPCTractor`, `stopNPCFieldWork`.
  - Ownership: `_flipFarmlandOwnership`, `_restoreFarmlandOwnership`, `_restoreNPCFieldOwnership`, `restoreAllOwnershipFlips` (called at top of `saveToXMLFile`).
  - Seat/hide: `seatNPCInVehicle` + `onNPCCharacterLoaded` (correct 4-arg loadCharacter), `setNPCEntityHidden`.
- `src/scripts/NPCAI.lua`: `startWorking`, `updateWorkingState` (drives combo kinematically when `usingComboFieldWork`, follows the AI-driven combo when `goToActive`).
- `src/scripts/NPCEntity.lua`: hotspots. `getSharedHotspotIcon` (the one shared overlay), `createMapHotspot`, `removeMapHotspot` (does NOT delete, would free the shared overlay), `_addHotspotToList` / `_removeHotspotFromList` (`mapHotspotInList` flag).

## Verified base-game vehicle paths (exist on disk)

- Tractors: `data/vehicles/fendt/vario500/vario500.xml`, `.../vario700/vario700.xml`.
- Implements (till): `data/vehicles/poettinger/servoT6000Plus/...` (plow), `data/vehicles/kuhn/kuhnCultimer400/...` (cultivator; often invalid at runtime, pool drops it -> only the plow remains).
- Seeders: `data/vehicles/amazone/citan15001C/...`, `data/vehicles/horsch/avatar1225/...`, `data/vehicles/vaderstad/nzExtreme1425/...`.
- Harvest combos (combine + header, brand-paired): `claas/lexion6900` + `claas/convioFlex1080`; `newHolland/cr980_830` + `newHolland/varifeed28` (this pair's header attach is the failing one).

## FS25 API facts (confirmed, do not re-derive)

- `AIJobFieldWork`: after createJob(FIELDWORK) + set vehicle/position, you MUST call `job:setValues()` before `startJob` (wires the tasks), or `AITaskDriveTo` runs on a nil vehicle and spams. `validate()` only checks the vehicle param.
- Field ownership: AI field work checks `getIsOwnedByFarmAtWorldPosition(jobFarmId, x, z)` every frame; unowned -> "field not owned". `AIJobGoTo` has NO such check. No farm-creation API; use `g_farmlandManager:setLandOwnership(farmlandId, farmId)` (owner 0 = unowned).
- `VehicleCharacter:loadCharacter(playerStyle, asyncCallbackObject, asyncCallbackFunction, asyncCallbackArguments)` invoked as `asyncCallbackFunction(asyncCallbackObject, loadingState, args)`.
- `Vehicle:delete()` is the real deletion API. `g_currentMission:removeVehicle` does not exist.
- Attach: `tractor:attachImplement(implement, inputJointIndex, attacherJointIndex)`; find via `getAttacherJoints()` (free = `jointIndex == 0`) vs `implement:getInputAttacherJoints()`, matching `jointType` + `AttacherJoints.getAttacherJointCompatibility(...)`.

## How to test a build

Reload the save (FS25 loads mod code on save load). Then in the log look for:
- `Vehicle pools validated: N tractors, N implements, N seeders, N harvest combos`.
- `Real tractor spawned for <name> ... <path>` and `Implement attached ...` (or `attach failed`).
- At work: `tilling field via base-game AI (temp ownership)`, `driving combo via base-game AI (GoTo)`, or `field need=..., skipping`.
- Confirm 0 `Unknown entity id`, 0 `Can't change money of spectator farm`, 0 VehicleCharacter errors.

## Ecosystem context

- The OM (organic certification) baseline in SoilFertilizer is done + on the ledger. Ecosystem is ON HOLD for Jrock's baseline-rebuild + roadmap pass (100+ "point docs"). NPCFavor field work is SF-independent and NOT part of that hold.
- Ledger: `../ecosystem-dev-tracking/CLAUDE-LOG.md` (private repo). Signed off for the session there.
